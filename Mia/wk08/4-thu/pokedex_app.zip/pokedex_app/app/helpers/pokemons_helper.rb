module PokemonsHelper
end
