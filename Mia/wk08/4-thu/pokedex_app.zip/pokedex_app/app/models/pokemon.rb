class Pokemon < ApplicationRecord
end
